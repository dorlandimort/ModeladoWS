
public interface Matriz {
	
	public double[] trasladar(double[] puntoInicial, double[] vectorTraslacion);

}
