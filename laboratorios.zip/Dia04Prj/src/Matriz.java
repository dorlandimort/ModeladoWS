
public interface Matriz {
	
	public double[] trasladar(double[] puntoInicial, double[] vectorTraslacion);
	
	public double[] escalar(double[] puntoInicial, int dimension, double k);

}
