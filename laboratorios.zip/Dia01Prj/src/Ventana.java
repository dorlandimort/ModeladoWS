import javax.swing.JFrame;


public class Ventana extends JFrame {
	public Ventana() {
		this.add(new Panel1());
	}
}
